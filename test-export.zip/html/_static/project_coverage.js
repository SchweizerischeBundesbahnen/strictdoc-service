const PC_TABLE_SELECTOR = 'js-project_coverage';
console.log(PC_TABLE_SELECTOR);
