Stimulus.register("scroll_into_view", class extends Controller {
  connect() {
    this.element.scrollIntoView()
  }
});
